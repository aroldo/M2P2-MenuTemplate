
#include "menutemplate.buildv1.1.09/windows_debug/include/menutemplate_menutemplate.h"

#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_app_2app.h"
#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_app_2event.h"
#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_app_2view.h"
#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_graphics_2canvas.h"
#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_graphics_2font.h"
#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_graphics_2image.h"
#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_input_2mouse.h"
#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_contentmanager.h"
#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_drawdata.h"
#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_loaderscreen.h"
#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_screenmanager.h"
#include "pyro-gui/pyro-gui.buildv1.1.09/windows_debug/include/pyro_5gui_pyro_5gui.h"
#include "pyro-scenegraph/pyro-scenegraph.buildv1.1.09/windows_debug/include/pyro_5scenegraph_pyro_5scenegraph.h"
#include "std/std.buildv1.1.09/windows_debug/include/std_geom_2vec2.h"
#include "std/std.buildv1.1.09/windows_debug/include/std_graphics_2color.h"
#include "menutemplate.buildv1.1.09/windows_debug/include/menutemplate_menutemplate.h"

enum class t_mojo_app_WindowFlags;
bbString bbDBType(t_mojo_app_WindowFlags*);
bbString bbDBValue(t_mojo_app_WindowFlags*);
struct t_mojo_graphics_Shader;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_graphics_Shader* const& );
#endif
bbString bbDBType(t_mojo_graphics_Shader**);
bbString bbDBValue(t_mojo_graphics_Shader**);
enum class t_mojo_graphics_TextureFlags;
bbString bbDBType(t_mojo_graphics_TextureFlags*);
bbString bbDBValue(t_mojo_graphics_TextureFlags*);
enum class t_mojo_input_Key;
bbString bbDBType(t_mojo_input_Key*);
bbString bbDBValue(t_mojo_input_Key*);

extern bbInt g_pyro_framework_commoncode_PercentageOf(bbFloat l_percentage,bbFloat l_value);
extern t_std_geom_Vec2_1f g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f(t_std_geom_Vec2_1i &l_self);
bbString g_default_FACEBOOK;
bbString g_default_TWITTER;
bbString g_default_PLAYNIAX;
bbInt g_default_WINDOW_0WIDTH;
bbInt g_default_WINDOW_0HEIGHT;
bbGCVar<t_default_Game> g_default_game;
bbGCVar<t_default_Loader> g_default_loader;
bbGCVar<t_default_Menu> g_default_menu;
t_std_geom_Vec2_1i g_default_virtualResolution;
bbString g_default_layout;
t_std_geom_Vec2_1f g_default_gravity;
bbInt g_default_Game_PAUSE;
bbInt g_default_Game_PAUSED;
bbGCVar<t_pyro_scenegraph_Camera> g_default_Game_camera;
bbArray<bbGCVar<t_pyro_gui_GuiLayer>> g_default_Game_guiLayer;
bbInt g_default_Game_guiPage;
bbGCVar<t_pyro_scenegraph_Layer> g_default_Game_layer;
bbGCVar<t_pyro_scenegraph_Scene> g_default_Game_scene;
bbInt g_default_Menu_ABOUT;
bbInt g_default_Menu_HELP;
bbInt g_default_Menu_OPTION1;
bbInt g_default_Menu_OPTION2;
bbInt g_default_Menu_OPTION3;
bbInt g_default_Menu_OPTION4;
bbInt g_default_Menu_OPTION5;
bbInt g_default_Menu_SETTINGS;
bbInt g_default_Menu_START;
bbArray<bbGCVar<t_pyro_gui_GuiLayer>> g_default_Menu_guiLayer;
bbInt g_default_Menu_guiPage;

void bbMain(){
  static bool done;
  if(done) return;
  done=true;
  void mx2_monkey_main();mx2_monkey_main();
  void mx2_mojo_main();mx2_mojo_main();
  void mx2_pyro_5framework_main();mx2_pyro_5framework_main();
  void mx2_pyro_5gui_main();mx2_pyro_5gui_main();
  void mx2_pyro_5scenegraph_main();mx2_pyro_5scenegraph_main();
  void mx2_std_main();mx2_std_main();
  void mx2_menutemplate_menutemplate_init_f();mx2_menutemplate_menutemplate_init_f();
  bbDBFrame db_f{"Main:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  bbDBStmt(3547137);
  bbGCNew<t_mojo_app_AppInstance>();
  bbDBStmt(3555329);
  bbGCNew<t_default_MenuOptions>(bbString(L"MenuTemplate",12),g_default_WINDOW_0WIDTH,g_default_WINDOW_0HEIGHT,t_mojo_app_WindowFlags(8));
  bbDBStmt(3563521);
  g_mojo_app_App.get()->m_Run();
}

void t_default_Game::dbEmit(){
  t_pyro_framework_screenmanager_Screen::dbEmit();
  puts( "[default.Game]");
}

t_default_Game::t_default_Game():t_pyro_framework_screenmanager_Screen(){
  struct f0_t : public bbGCFrame{
    t_pyro_gui_GuiImage* l_background{};
    t_default_Button* l_continueButton{};
    t_default_Button* l_pauseButton{};
    t_pyro_gui_GuiGroup* l_pausedWindow{};
    t_default_Button* l_quitButton{};
    t_mojo_app_View* t0{};
    t_mojo_graphics_Image* t1{};
    t_std_geom_Vec2_1i t2{};
    void gcMark(){
      bbGCMark(l_background);
      bbGCMark(l_continueButton);
      bbGCMark(l_pauseButton);
      bbGCMark(l_pausedWindow);
      bbGCMark(l_quitButton);
      bbGCMark(t0);
      bbGCMark(t1);
      bbGCMark(t2);
    }
  }f0{};
  bbDBFrame db_f{"new:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Game*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(376834);
  g_default_Game_scene=bbGCNew<t_pyro_scenegraph_Scene>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(380930);
  g_default_Game_camera=bbGCNew<t_pyro_scenegraph_Camera>(g_default_Game_scene.get());
  bbDBStmt(385026);
  g_default_Game_layer=bbGCNew<t_pyro_scenegraph_Layer>(g_default_Game_scene.get());
  bbDBStmt(397314);
  g_default_Game_guiLayer[g_default_Game_PAUSE]=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(401410);
  g_default_Game_guiLayer[g_default_Game_PAUSE].get()->m_Name(bbString(L"pause",5));
  bbDBStmt(413704);
  f0.l_pauseButton=bbGCNew<t_default_Button>();
  bbDBLocal("pauseButton",&f0.l_pauseButton);
  bbDBStmt(417794);
  f0.l_pauseButton->m_Layer(g_default_Game_guiLayer[g_default_Game_PAUSE].get());
  bbDBStmt(421890);
  f0.l_pauseButton->m_Name(bbString(L"pause",5));
  bbDBStmt(425986);
  f0.l_pauseButton->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::pause_idle.png",21),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(430082);
  f0.l_pauseButton->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::pause_down.png",21),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(434178);
  f0.l_pauseButton->m_Location=t_std_geom_Vec2_1f{bbFloat(g_pyro_framework_commoncode_PercentageOf(95.0f,bbFloat(g_default_virtualResolution.m_X()))),bbFloat(g_pyro_framework_commoncode_PercentageOf(5.0f,bbFloat(g_default_virtualResolution.m_Y())))};
  bbDBStmt(438274);
  f0.l_pauseButton->m_Pausable(false);
  bbDBStmt(450562);
  g_default_Game_guiLayer[g_default_Game_PAUSED]=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(454658);
  g_default_Game_guiLayer[g_default_Game_PAUSED].get()->m_Name(bbString(L"paused",6));
  bbDBStmt(466952);
  f0.l_pausedWindow=bbGCNew<t_pyro_gui_GuiGroup>();
  bbDBLocal("pausedWindow",&f0.l_pausedWindow);
  bbDBStmt(471042);
  f0.l_pausedWindow->m_Layer(g_default_Game_guiLayer[g_default_Game_PAUSED].get());
  bbDBStmt(475138);
  f0.l_pausedWindow->m_Name(bbString(L"window",6));
  bbDBStmt(479234);
  f0.l_pausedWindow->m_Width((f0.t1=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/paused_window.png",31),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Width());
  bbDBStmt(483330);
  f0.l_pausedWindow->m_Height((f0.t1=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/paused_window.png",31),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Height());
  bbDBStmt(487426);
  f0.l_pausedWindow->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t2=g_default_virtualResolution.m__div(2.0)));
  bbDBStmt(499720);
  f0.l_background=bbGCNew<t_pyro_gui_GuiImage>();
  bbDBLocal("background",&f0.l_background);
  bbDBStmt(503810);
  f0.l_background->m_Group(f0.l_pausedWindow);
  bbDBStmt(507906);
  f0.l_background->m_Name(bbString(L"background",10));
  bbDBStmt(512002);
  f0.l_background->m_Location=t_std_geom_Vec2_1f{(f0.l_pausedWindow->m_Width()/2.0f),(f0.l_pausedWindow->m_Height()/2.0f)};
  bbDBStmt(516098);
  f0.l_background->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/paused_window.png",31),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(528392);
  f0.l_continueButton=bbGCNew<t_default_Button>();
  bbDBLocal("continueButton",&f0.l_continueButton);
  bbDBStmt(532482);
  f0.l_continueButton->m_Group(f0.l_pausedWindow);
  bbDBStmt(536578);
  f0.l_continueButton->m_Name(bbString(L"continue",8));
  bbDBStmt(540674);
  f0.l_continueButton->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/continue_idle.png",31),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(544770);
  f0.l_continueButton->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/continue_down.png",31),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(548866);
  f0.l_continueButton->m_Location=t_std_geom_Vec2_1f{270.0f,104.0f};
  bbDBStmt(552962);
  f0.l_continueButton->m_Pausable(false);
  bbDBStmt(565256);
  f0.l_quitButton=bbGCNew<t_default_Button>();
  bbDBLocal("quitButton",&f0.l_quitButton);
  bbDBStmt(569346);
  f0.l_quitButton->m_Group(f0.l_pausedWindow);
  bbDBStmt(573442);
  f0.l_quitButton->m_Name(bbString(L"quit",4));
  bbDBStmt(577538);
  f0.l_quitButton->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/quit_idle.png",27),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(581634);
  f0.l_quitButton->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/quit_down.png",27),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(585730);
  f0.l_quitButton->m_Location=t_std_geom_Vec2_1f{270.0f,226.0f};
  bbDBStmt(589826);
  f0.l_quitButton->m_Pausable(false);
  bbDBStmt(598018);
  bbGCNew<t_pyro_gui_GuiLoader>(bbString(L"asset::paused.txt",17),g_default_Game_guiLayer[g_default_Game_PAUSED].get());
}
t_default_Game::~t_default_Game(){
}

void t_default_Game::m_RunOnce(){
  bbDBFrame db_f{"RunOnce:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Game*self=this;
  bbDBLocal("Self",&self);
}

void t_default_Game::m_OnUpdate(){
  bbDBFrame db_f{"OnUpdate:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Game*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(790530);
  g_default_Game_scene.get()->m_Update();
  bbDBStmt(798722);
  g_default_Game_guiLayer[g_default_Game_guiPage].get()->m_Update();
}

void t_default_Game::m_OnStop(){
  bbDBFrame db_f{"OnStop:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Game*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(757762);
  g_default_Game_guiPage=g_default_Game_PAUSE;
}

void t_default_Game::m_OnStart(){
  bbDBFrame db_f{"OnStart:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Game*self=this;
  bbDBLocal("Self",&self);
}

void t_default_Game::m_OnRender(t_mojo_graphics_Canvas* l_canvas){
  bbDBFrame db_f{"OnRender:Void(canvas:mojo.graphics.Canvas)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Game*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
  bbDBStmt(712706);
  g_default_Game_scene.get()->m_Draw(l_canvas);
  bbDBStmt(720898);
  g_default_Game_guiLayer[g_default_Game_guiPage].get()->m_Draw(l_canvas);
}

void t_default_Game::m_OnMouseEvent(t_mojo_app_MouseEvent* l_event){
  bbDBFrame db_f{"OnMouseEvent:Void(event:mojo.app.MouseEvent)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Game*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbDBStmt(684034);
  g_default_Game_guiLayer[g_default_Game_guiPage].get()->m_SendMouseEvent(l_event);
}

void t_default_Game::m_OnKeyEvent(t_mojo_app_KeyEvent* l_event){
  bbDBFrame db_f{"OnKeyEvent:Void(event:mojo.app.KeyEvent)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Game*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbDBStmt(626690);
  g_default_Game_guiLayer[g_default_Game_guiPage].get()->m_SendKeyEvent(l_event);
  t_mojo_app_EventType l_0=l_event->m_Type();
  bbDBLocal("0",&l_0);
  bbDBStmt(634882);
  if((l_0==t_mojo_app_EventType(0))){
    bbDBBlock db_blk;
    t_mojo_input_Key l_1=l_event->m_Key();
    bbDBLocal("1",&l_1);
    bbDBStmt(643075);
    if((l_1==t_mojo_input_Key(27))){
      bbDBBlock db_blk;
      bbDBStmt(651269);
      g_default_menu.get()->m_Set();
    }
  }
}
bbString bbDBType(t_default_Game**){
  return "default.Game";
}
bbString bbDBValue(t_default_Game**p){
  return bbDBObjectValue(*p);
}

void t_default_Loader::gcMark(){
  t_pyro_framework_loaderscreen_LoaderScreen::gcMark();
  bbGCMark(m_guiLayer);
  bbGCMark(m_progressBar);
}

void t_default_Loader::dbEmit(){
  t_pyro_framework_loaderscreen_LoaderScreen::dbEmit();
  puts( "[default.Loader]");
  bbDBEmit("guiLayer",&m_guiLayer);
  bbDBEmit("progressBar",&m_progressBar);
}

t_default_Loader::t_default_Loader(){
  struct f0_t : public bbGCFrame{
    t_pyro_gui_GuiImage* l_background{};
    t_pyro_gui_GuiImage* l_logo{};
    t_mojo_app_View* t0{};
    t_mojo_graphics_Image* t1{};
    t_std_geom_Vec2_1i t2{};
    void gcMark(){
      bbGCMark(l_background);
      bbGCMark(l_logo);
      bbGCMark(t0);
      bbGCMark(t1);
      bbGCMark(t2);
    }
  }f0{};
  bbDBFrame db_f{"new:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Loader*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(872450);
  this->m_guiLayer=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(876546);
  this->m_guiLayer.get()->m_Width((f0.t1=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Width());
  bbDBStmt(880642);
  this->m_guiLayer.get()->m_Height((f0.t1=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Height());
  bbDBStmt(884738);
  this->m_guiLayer.get()->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t2=g_default_virtualResolution.m__div(2.0).m__sub(t_std_geom_Vec2_1i{bbInt(this->m_guiLayer.get()->m_Width()),bbInt(this->m_guiLayer.get()->m_Height())}.m__div(2.0))));
  bbDBStmt(897032);
  f0.l_background=bbGCNew<t_pyro_gui_GuiImage>();
  bbDBLocal("background",&f0.l_background);
  bbDBStmt(901122);
  f0.l_background->m_Layer(this->m_guiLayer.get());
  bbDBStmt(905218);
  f0.l_background->m_Location=t_std_geom_Vec2_1f{bbFloat(g_pyro_framework_commoncode_PercentageOf(50.0f,bbFloat(g_default_virtualResolution.m_X()))),bbFloat(g_pyro_framework_commoncode_PercentageOf(50.0f,bbFloat(g_default_virtualResolution.m_Y())))};
  bbDBStmt(909314);
  f0.l_background->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(921608);
  f0.l_logo=bbGCNew<t_pyro_gui_GuiImage>();
  bbDBLocal("logo",&f0.l_logo);
  bbDBStmt(925698);
  f0.l_logo->m_Layer(this->m_guiLayer.get());
  bbDBStmt(929794);
  f0.l_logo->m_Location=t_std_geom_Vec2_1f{bbFloat(g_pyro_framework_commoncode_PercentageOf(50.0f,bbFloat(g_default_virtualResolution.m_X()))),bbFloat(g_pyro_framework_commoncode_PercentageOf(50.0f,bbFloat(g_default_virtualResolution.m_Y())))};
  bbDBStmt(933890);
  f0.l_logo->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/playniax_logo.png",31),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(946178);
  this->m_progressBar=bbGCNew<t_pyro_gui_GuiHProgressBar>();
  bbDBStmt(950274);
  this->m_progressBar.get()->m_Layer(this->m_guiLayer.get());
  bbDBStmt(954370);
  this->m_progressBar.get()->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/loaderbar.png",27),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(958466);
  this->m_progressBar.get()->m_Indicator.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/loaderbar_progress.png",36),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(962562);
  this->m_progressBar.get()->m_Indicator.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Location=t_std_geom_Vec2_1f{3.0f,3.0f};
  bbDBStmt(966658);
  this->m_progressBar.get()->m_Location=t_std_geom_Vec2_1f{bbFloat(g_pyro_framework_commoncode_PercentageOf(50.0f,bbFloat(g_default_virtualResolution.m_X()))),bbFloat(g_pyro_framework_commoncode_PercentageOf(90.0f,bbFloat(g_default_virtualResolution.m_Y())))};
}
t_default_Loader::~t_default_Loader(){
}

void t_default_Loader::m_RunOnce(){
  bbDBFrame db_f{"RunOnce:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Loader*self=this;
  bbDBLocal("Self",&self);
}

void t_default_Loader::m_OnUpdate(){
  bbDBFrame db_f{"OnUpdate:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Loader*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1257474);
  this->m_guiLayer.get()->m_Update();
}

void t_default_Loader::m_OnStop(){
  bbDBFrame db_f{"OnStop:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Loader*self=this;
  bbDBLocal("Self",&self);
}

void t_default_Loader::m_OnStart(){
  bbDBFrame db_f{"OnStart:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Loader*self=this;
  bbDBLocal("Self",&self);
}

void t_default_Loader::m_OnRender(t_mojo_graphics_Canvas* l_canvas){
  bbDBFrame db_f{"OnRender:Void(canvas:mojo.graphics.Canvas)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Loader*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
  bbDBStmt(1187842);
  t_pyro_framework_loaderscreen_LoaderScreen::m_OnRender(l_canvas);
  bbDBStmt(1191938);
  this->m_guiLayer.get()->m_Draw(l_canvas);
  bbDBStmt(1204226);
  this->m_progressBar.get()->m_Maximum=this->m_LoadingSteps();
  bbDBStmt(1208322);
  this->m_progressBar.get()->m_Value=this->m_CurrentStep();
}

void t_default_Loader::m_OnLoading(){
  bbDBFrame db_f{"OnLoading:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Loader*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1003523);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1015810);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1019907);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1032194);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1036291);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1048578);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1052675);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1064962);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1069059);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1081346);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1085443);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1097730);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1101827);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1114114);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1118211);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1130498);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1134595);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
  bbDBStmt(1146882);
  if(this->m_Loading()){
    bbDBBlock db_blk;
    bbDBStmt(1150979);
    bb_print(((((bbString(L"Replace this print command with a load command... ( Current step is ",68)+bbString(this->m_CurrentStep()))+bbString(L" of ",4))+bbString(this->m_LoadingSteps()))+bbString(L" in total )",11)));
  }
}
bbString bbDBType(t_default_Loader**){
  return "default.Loader";
}
bbString bbDBValue(t_default_Loader**p){
  return bbDBObjectValue(*p);
}

void t_default_Menu::gcMark(){
  t_pyro_framework_screenmanager_Screen::gcMark();
  bbGCMark(m_lbsize);
  bbGCMark(m_lblayout);
  bbGCMark(m_lbgravity);
  bbGCMark(m_lbmouse);
}

void t_default_Menu::dbEmit(){
  t_pyro_framework_screenmanager_Screen::dbEmit();
  puts( "[default.Menu]");
  bbDBEmit("mouse",&m_mouse);
  bbDBEmit("lbposy",&m_lbposy);
  bbDBEmit("lbposx",&m_lbposx);
  bbDBEmit("lbsize",&m_lbsize);
  bbDBEmit("lblayout",&m_lblayout);
  bbDBEmit("lbgravity",&m_lbgravity);
  bbDBEmit("lbmouse",&m_lbmouse);
}

t_default_Menu::t_default_Menu():t_pyro_framework_screenmanager_Screen(){
  struct f0_t : public bbGCFrame{
    t_default_Button* l_backButtonOPTION4{};
    t_default_Button* l_backButtonOPTION5{};
    t_default_Button* l_backButtonOption1{};
    t_default_Button* l_backButtonOption2{};
    t_default_Button* l_backButtonOption3{};
    t_default_Button* l_option1Button{};
    t_pyro_gui_GuiImage* l_option1Title{};
    t_default_Button* l_option2Button{};
    t_pyro_gui_GuiImage* l_option2Title{};
    t_default_Button* l_option3Button{};
    t_pyro_gui_GuiImage* l_option3Title{};
    t_default_Button* l_option4Button{};
    t_pyro_gui_GuiImage* l_option4Title{};
    t_default_Button* l_option5Button{};
    t_pyro_gui_GuiImage* l_option5Title{};
    t_mojo_app_View* t0{};
    t_std_geom_Vec2_1i t1{};
    t_mojo_graphics_Image* t2{};
    void gcMark(){
      bbGCMark(l_backButtonOPTION4);
      bbGCMark(l_backButtonOPTION5);
      bbGCMark(l_backButtonOption1);
      bbGCMark(l_backButtonOption2);
      bbGCMark(l_backButtonOption3);
      bbGCMark(l_option1Button);
      bbGCMark(l_option1Title);
      bbGCMark(l_option2Button);
      bbGCMark(l_option2Title);
      bbGCMark(l_option3Button);
      bbGCMark(l_option3Title);
      bbGCMark(l_option4Button);
      bbGCMark(l_option4Title);
      bbGCMark(l_option5Button);
      bbGCMark(l_option5Title);
      bbGCMark(t0);
      bbGCMark(t1);
      bbGCMark(t2);
    }
  }f0{};
  bbDBFrame db_f{"new:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Menu*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1400834);
  g_default_Menu_guiLayer[g_default_Menu_START]=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(1404930);
  g_default_Menu_guiLayer[g_default_Menu_START].get()->m_Name(bbString(L"start",5));
  bbDBStmt(1409026);
  g_default_Menu_guiLayer[g_default_Menu_START].get()->m_Width(bbFloat(g_default_WINDOW_0WIDTH));
  bbDBStmt(1413122);
  g_default_Menu_guiLayer[g_default_Menu_START].get()->m_Height(bbFloat(g_default_WINDOW_0HEIGHT));
  bbDBStmt(1417218);
  g_default_Menu_guiLayer[g_default_Menu_START].get()->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt(0),bbInt(0)}));
  bbDBStmt(1486850);
  this->m_lbsize=bbGCNew<t_pyro_gui_GuiLabel>();
  bbDBStmt(1490946);
  this->m_lbsize.get()->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1495042);
  this->m_lbsize.get()->m_Name(bbString(L"lbsize",6));
  bbDBStmt(1499138);
  this->m_lbsize.get()->m_Label.get()->m_Font=g_pyro_framework_contentmanager_Content.get()->m_GetFont(bbString(L"asset::fonts/font",17),42.0f,((t_mojo_graphics_Shader*)0));
  bbDBStmt(1503234);
  this->m_lbsize.get()->m_Label.get()->m_Text=(bbString(L"Screen Size=",12)+g_default_virtualResolution.m_to_s());
  bbDBStmt(1507330);
  this->m_lbsize.get()->m_Color=g_std_graphics_Color_White;
  bbDBStmt(1511426);
  this->m_lbsize.get()->m_Location=t_std_geom_Vec2_1f{bbFloat(this->m_lbposx),bbFloat(this->m_lbposy)};
  bbDBStmt(1515522);
  this->m_lblayout=bbGCNew<t_pyro_gui_GuiLabel>();
  bbDBStmt(1519618);
  this->m_lblayout.get()->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1523714);
  this->m_lblayout.get()->m_Name(bbString(L"lblayout",8));
  bbDBStmt(1527810);
  this->m_lblayout.get()->m_Label.get()->m_Font=g_pyro_framework_contentmanager_Content.get()->m_GetFont(bbString(L"asset::fonts/font",17),42.0f,((t_mojo_graphics_Shader*)0));
  bbDBStmt(1531906);
  this->m_lblayout.get()->m_Label.get()->m_Text=((bbString(L"Layout=\"",8)+g_default_layout)+bbString(L"\"  ('L' to cycle)",17));
  bbDBStmt(1536002);
  this->m_lblayout.get()->m_Color=g_std_graphics_Color_White;
  bbDBStmt(1540098);
  this->m_lblayout.get()->m_Location=t_std_geom_Vec2_1f{bbFloat(this->m_lbposx),bbFloat((this->m_lbposy*2))};
  bbDBStmt(1548290);
  this->m_lbgravity=bbGCNew<t_pyro_gui_GuiLabel>();
  bbDBStmt(1552386);
  this->m_lbgravity.get()->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1556482);
  this->m_lbgravity.get()->m_Name(bbString(L"lbgravity",9));
  bbDBStmt(1560578);
  this->m_lbgravity.get()->m_Label.get()->m_Font=g_pyro_framework_contentmanager_Content.get()->m_GetFont(bbString(L"asset::fonts/font",17),42.0f,((t_mojo_graphics_Shader*)0));
  bbDBStmt(1564674);
  this->m_lbgravity.get()->m_Label.get()->m_Text=((bbString(L"Gravity=",8)+g_default_gravity.m_to_s())+bbString(L"  ('G' to cycle)",16));
  bbDBStmt(1568770);
  this->m_lbgravity.get()->m_Color=g_std_graphics_Color_White;
  bbDBStmt(1572866);
  this->m_lbgravity.get()->m_Location=t_std_geom_Vec2_1f{bbFloat(this->m_lbposx),bbFloat((this->m_lbposy*3))};
  bbDBStmt(1581058);
  this->m_lbmouse=bbGCNew<t_pyro_gui_GuiLabel>();
  bbDBStmt(1585154);
  this->m_lbmouse.get()->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1589250);
  this->m_lbmouse.get()->m_Name(bbString(L"lbmouse",7));
  bbDBStmt(1593346);
  this->m_lbmouse.get()->m_Label.get()->m_Font=g_pyro_framework_contentmanager_Content.get()->m_GetFont(bbString(L"asset::fonts/font",17),42.0f,((t_mojo_graphics_Shader*)0));
  bbDBStmt(1597442);
  this->m_lbmouse.get()->m_Label.get()->m_Text=(bbString(L"Mouse=",6)+this->m_mouse.m_to_s());
  bbDBStmt(1601538);
  this->m_lbmouse.get()->m_Color=g_std_graphics_Color_White;
  bbDBStmt(1605634);
  this->m_lbmouse.get()->m_Location=t_std_geom_Vec2_1f{bbFloat(this->m_lbposx),bbFloat((this->m_lbposy*4))};
  bbDBStmt(1617928);
  f0.l_option1Button=bbGCNew<t_default_Button>();
  bbDBLocal("option1Button",&f0.l_option1Button);
  bbDBStmt(1622018);
  f0.l_option1Button->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1626114);
  f0.l_option1Button->m_Name(bbString(L"option1",7));
  bbDBStmt(1630210);
  f0.l_option1Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption1.png",28),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1634306);
  f0.l_option1Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption1on.png",30),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1662978);
  f0.l_option1Button->m_Location=t_std_geom_Vec2_1f{(f0.l_option1Button->m_Width()*0.5f),(f0.l_option1Button->m_Height()*0.5f)};
  bbDBStmt(1671176);
  f0.l_option2Button=bbGCNew<t_default_Button>();
  bbDBLocal("option2Button",&f0.l_option2Button);
  bbDBStmt(1675266);
  f0.l_option2Button->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1679362);
  f0.l_option2Button->m_Name(bbString(L"option2",7));
  bbDBStmt(1683458);
  f0.l_option2Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption2.png",28),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1687554);
  f0.l_option2Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption2on.png",30),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1691650);
  f0.l_option2Button->m_Location=t_std_geom_Vec2_1f{(f0.l_option2Button->m_Width()*1.5f),(f0.l_option1Button->m_Height()*0.5f)};
  bbDBStmt(1699848);
  f0.l_option3Button=bbGCNew<t_default_Button>();
  bbDBLocal("option3Button",&f0.l_option3Button);
  bbDBStmt(1703938);
  f0.l_option3Button->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1708034);
  f0.l_option3Button->m_Name(bbString(L"option3",7));
  bbDBStmt(1712130);
  f0.l_option3Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption3.png",28),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1716226);
  f0.l_option3Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption3on.png",30),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1720322);
  f0.l_option3Button->m_Location=t_std_geom_Vec2_1f{(f0.l_option3Button->m_Width()*2.5f),(f0.l_option1Button->m_Height()*0.5f)};
  bbDBStmt(1728520);
  f0.l_option4Button=bbGCNew<t_default_Button>();
  bbDBLocal("option4Button",&f0.l_option4Button);
  bbDBStmt(1732610);
  f0.l_option4Button->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1736706);
  f0.l_option4Button->m_Name(bbString(L"option4",7));
  bbDBStmt(1740802);
  f0.l_option4Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption4.png",28),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1744898);
  f0.l_option4Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption4on.png",30),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1748994);
  f0.l_option4Button->m_Location=t_std_geom_Vec2_1f{(f0.l_option4Button->m_Width()*3.5f),(f0.l_option1Button->m_Height()*0.5f)};
  bbDBStmt(1757192);
  f0.l_option5Button=bbGCNew<t_default_Button>();
  bbDBLocal("option5Button",&f0.l_option5Button);
  bbDBStmt(1761282);
  f0.l_option5Button->m_Layer(g_default_Menu_guiLayer[g_default_Menu_START].get());
  bbDBStmt(1765378);
  f0.l_option5Button->m_Name(bbString(L"option5",7));
  bbDBStmt(1769474);
  f0.l_option5Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption5.png",28),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1773570);
  f0.l_option5Button->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btoption5on.png",30),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1777666);
  f0.l_option5Button->m_Location=t_std_geom_Vec2_1f{(f0.l_option5Button->m_Width()*4.5f),(f0.l_option1Button->m_Height()*0.5f)};
  bbDBStmt(1859586);
  g_default_Menu_guiLayer[g_default_Menu_START].get()->m_ZSort();
  bbDBStmt(1871874);
  g_default_Menu_guiLayer[g_default_Menu_OPTION1]=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(1875970);
  g_default_Menu_guiLayer[g_default_Menu_OPTION1].get()->m_Name(bbString(L"option1",7));
  bbDBStmt(1880066);
  g_default_Menu_guiLayer[g_default_Menu_OPTION1].get()->m_Width(bbFloat(g_default_WINDOW_0WIDTH));
  bbDBStmt(1884162);
  g_default_Menu_guiLayer[g_default_Menu_OPTION1].get()->m_Height(bbFloat(g_default_WINDOW_0HEIGHT));
  bbDBStmt(1888258);
  g_default_Menu_guiLayer[g_default_Menu_OPTION1].get()->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=g_default_virtualResolution.m__div(2.0).m__sub(t_std_geom_Vec2_1i{bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION1].get()->m_Width()),bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION1].get()->m_Height())}.m__div(2.0))));
  bbDBStmt(1904648);
  f0.l_option1Title=bbGCNew<t_pyro_gui_GuiImage>();
  bbDBLocal("option1Title",&f0.l_option1Title);
  bbDBStmt(1908738);
  f0.l_option1Title->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION1].get());
  bbDBStmt(1912834);
  f0.l_option1Title->m_Name(bbString(L"option1title",12));
  bbDBStmt(1916930);
  f0.l_option1Title->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/options1.png",26),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1925122);
  f0.l_option1Title->m_Location=t_std_geom_Vec2_1f{bbFloat(g_pyro_framework_commoncode_PercentageOf(10.0f,bbFloat(g_default_virtualResolution.m_X()))),bbFloat(g_pyro_framework_commoncode_PercentageOf(5.0f,bbFloat(g_default_virtualResolution.m_Y())))};
  bbDBStmt(1937416);
  f0.l_backButtonOption1=bbGCNew<t_default_Button>();
  bbDBLocal("backButtonOption1",&f0.l_backButtonOption1);
  bbDBStmt(1941506);
  f0.l_backButtonOption1->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION1].get());
  bbDBStmt(1945602);
  f0.l_backButtonOption1->m_Name(bbString(L"back",4));
  bbDBStmt(1949698);
  f0.l_backButtonOption1->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btback.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1953794);
  f0.l_backButtonOption1->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btbackon.png",27),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(1957890);
  f0.l_backButtonOption1->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt((bbFloat(g_default_WINDOW_0WIDTH)-f0.l_backButtonOption1->m_Width())),bbInt((bbFloat(g_default_WINDOW_0HEIGHT)-f0.l_backButtonOption1->m_Height()))}));
  bbDBStmt(1970178);
  g_default_Menu_guiLayer[g_default_Menu_OPTION2]=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(1974274);
  g_default_Menu_guiLayer[g_default_Menu_OPTION2].get()->m_Name(bbString(L"option2",7));
  bbDBStmt(1978370);
  g_default_Menu_guiLayer[g_default_Menu_OPTION2].get()->m_Width((f0.t2=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Width());
  bbDBStmt(1982466);
  g_default_Menu_guiLayer[g_default_Menu_OPTION2].get()->m_Height((f0.t2=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Height());
  bbDBStmt(1986562);
  g_default_Menu_guiLayer[g_default_Menu_OPTION2].get()->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=g_default_virtualResolution.m__div(2.0).m__sub(t_std_geom_Vec2_1i{bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION2].get()->m_Width()),bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION2].get()->m_Height())}.m__div(2.0))));
  bbDBStmt(1994760);
  f0.l_option2Title=bbGCNew<t_pyro_gui_GuiImage>();
  bbDBLocal("option2Title",&f0.l_option2Title);
  bbDBStmt(1998850);
  f0.l_option2Title->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION2].get());
  bbDBStmt(2002946);
  f0.l_option2Title->m_Name(bbString(L"option2title",12));
  bbDBStmt(2007042);
  f0.l_option2Title->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/option2.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2011138);
  f0.l_option2Title->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt(((bbFloat(g_default_WINDOW_0WIDTH)*0.5f)-(f0.l_option2Title->m_Width()*0.5f))),bbInt((f0.l_option2Title->m_Height()*0.5f))}));
  bbDBStmt(2023432);
  f0.l_backButtonOption2=bbGCNew<t_default_Button>();
  bbDBLocal("backButtonOption2",&f0.l_backButtonOption2);
  bbDBStmt(2027522);
  f0.l_backButtonOption2->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION2].get());
  bbDBStmt(2031618);
  f0.l_backButtonOption2->m_Name(bbString(L"back",4));
  bbDBStmt(2035714);
  f0.l_backButtonOption2->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btback.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2039810);
  f0.l_backButtonOption2->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btbackon.png",27),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2043906);
  f0.l_backButtonOption2->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt((bbFloat(g_default_WINDOW_0WIDTH)-f0.l_backButtonOption2->m_Width())),bbInt((bbFloat(g_default_WINDOW_0HEIGHT)-f0.l_backButtonOption2->m_Height()))}));
  bbDBStmt(2056194);
  g_default_Menu_guiLayer[g_default_Menu_OPTION3]=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(2060290);
  g_default_Menu_guiLayer[g_default_Menu_OPTION3].get()->m_Name(bbString(L"option3",7));
  bbDBStmt(2064386);
  g_default_Menu_guiLayer[g_default_Menu_OPTION3].get()->m_Width((f0.t2=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Width());
  bbDBStmt(2068482);
  g_default_Menu_guiLayer[g_default_Menu_OPTION3].get()->m_Height((f0.t2=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Height());
  bbDBStmt(2072578);
  g_default_Menu_guiLayer[g_default_Menu_OPTION3].get()->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=g_default_virtualResolution.m__div(2.0).m__sub(t_std_geom_Vec2_1i{bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION3].get()->m_Width()),bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION3].get()->m_Height())}.m__div(2.0))));
  bbDBStmt(2080776);
  f0.l_option3Title=bbGCNew<t_pyro_gui_GuiImage>();
  bbDBLocal("option3Title",&f0.l_option3Title);
  bbDBStmt(2084866);
  f0.l_option3Title->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION3].get());
  bbDBStmt(2088962);
  f0.l_option3Title->m_Name(bbString(L"option3title",12));
  bbDBStmt(2093058);
  f0.l_option3Title->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/option3.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2097154);
  f0.l_option3Title->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt(((bbFloat(g_default_WINDOW_0WIDTH)*0.5f)-(f0.l_option3Title->m_Width()*0.5f))),bbInt((f0.l_option3Title->m_Height()*2.5f))}));
  bbDBStmt(2109448);
  f0.l_backButtonOption3=bbGCNew<t_default_Button>();
  bbDBLocal("backButtonOption3",&f0.l_backButtonOption3);
  bbDBStmt(2113538);
  f0.l_backButtonOption3->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION3].get());
  bbDBStmt(2117634);
  f0.l_backButtonOption3->m_Name(bbString(L"back",4));
  bbDBStmt(2121730);
  f0.l_backButtonOption3->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btback.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2125826);
  f0.l_backButtonOption3->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btbackon.png",27),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2129922);
  f0.l_backButtonOption3->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt((bbFloat(g_default_WINDOW_0WIDTH)-f0.l_backButtonOption3->m_Width())),bbInt((bbFloat(g_default_WINDOW_0HEIGHT)-f0.l_backButtonOption3->m_Height()))}));
  bbDBStmt(2142210);
  g_default_Menu_guiLayer[g_default_Menu_OPTION4]=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(2146306);
  g_default_Menu_guiLayer[g_default_Menu_OPTION4].get()->m_Name(bbString(L"option4",7));
  bbDBStmt(2150402);
  g_default_Menu_guiLayer[g_default_Menu_OPTION4].get()->m_Width((f0.t2=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Width());
  bbDBStmt(2154498);
  g_default_Menu_guiLayer[g_default_Menu_OPTION4].get()->m_Height((f0.t2=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Height());
  bbDBStmt(2158594);
  g_default_Menu_guiLayer[g_default_Menu_OPTION4].get()->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=g_default_virtualResolution.m__div(2.0).m__sub(t_std_geom_Vec2_1i{bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION4].get()->m_Width()),bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION4].get()->m_Height())}.m__div(2.0))));
  bbDBStmt(2166792);
  f0.l_option4Title=bbGCNew<t_pyro_gui_GuiImage>();
  bbDBLocal("option4Title",&f0.l_option4Title);
  bbDBStmt(2170882);
  f0.l_option4Title->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION4].get());
  bbDBStmt(2174978);
  f0.l_option4Title->m_Name(bbString(L"option4title",12));
  bbDBStmt(2179074);
  f0.l_option4Title->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/option4.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2183170);
  f0.l_option4Title->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt(((bbFloat(g_default_WINDOW_0WIDTH)*0.5f)-(f0.l_option4Title->m_Width()*0.5f))),bbInt((f0.l_option4Title->m_Height()*3.5f))}));
  bbDBStmt(2195464);
  f0.l_backButtonOPTION4=bbGCNew<t_default_Button>();
  bbDBLocal("backButtonOPTION4",&f0.l_backButtonOPTION4);
  bbDBStmt(2199554);
  f0.l_backButtonOPTION4->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION4].get());
  bbDBStmt(2203650);
  f0.l_backButtonOPTION4->m_Name(bbString(L"back",4));
  bbDBStmt(2207746);
  f0.l_backButtonOPTION4->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btback.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2211842);
  f0.l_backButtonOPTION4->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btbackon.png",27),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2215938);
  f0.l_backButtonOPTION4->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt((bbFloat(g_default_WINDOW_0WIDTH)-f0.l_backButtonOPTION4->m_Width())),bbInt((bbFloat(g_default_WINDOW_0HEIGHT)-f0.l_backButtonOPTION4->m_Height()))}));
  bbDBStmt(2224130);
  g_default_Menu_guiLayer[g_default_Menu_OPTION5]=bbGCNew<t_pyro_gui_GuiLayer>(f0.t0=((t_mojo_app_View*)(this->m_ScreenManager())));
  bbDBStmt(2228226);
  g_default_Menu_guiLayer[g_default_Menu_OPTION5].get()->m_Name(bbString(L"option5",7));
  bbDBStmt(2232322);
  g_default_Menu_guiLayer[g_default_Menu_OPTION5].get()->m_Width((f0.t2=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Width());
  bbDBStmt(2236418);
  g_default_Menu_guiLayer[g_default_Menu_OPTION5].get()->m_Height((f0.t2=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/gui_background.png",32),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12)))->m_Height());
  bbDBStmt(2240514);
  g_default_Menu_guiLayer[g_default_Menu_OPTION5].get()->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=g_default_virtualResolution.m__div(2.0).m__sub(t_std_geom_Vec2_1i{bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION5].get()->m_Width()),bbInt(g_default_Menu_guiLayer[g_default_Menu_OPTION5].get()->m_Height())}.m__div(2.0))));
  bbDBStmt(2248712);
  f0.l_option5Title=bbGCNew<t_pyro_gui_GuiImage>();
  bbDBLocal("option5Title",&f0.l_option5Title);
  bbDBStmt(2252802);
  f0.l_option5Title->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION5].get());
  bbDBStmt(2256898);
  f0.l_option5Title->m_Name(bbString(L"option5title",12));
  bbDBStmt(2260994);
  f0.l_option5Title->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::images/option5.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2265090);
  f0.l_option5Title->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt(((bbFloat(g_default_WINDOW_0WIDTH)*0.5f)-(f0.l_option5Title->m_Width()*0.5f))),bbInt((f0.l_option5Title->m_Height()*4.5f))}));
  bbDBStmt(2277384);
  f0.l_backButtonOPTION5=bbGCNew<t_default_Button>();
  bbDBLocal("backButtonOPTION5",&f0.l_backButtonOPTION5);
  bbDBStmt(2281474);
  f0.l_backButtonOPTION5->m_Layer(g_default_Menu_guiLayer[g_default_Menu_OPTION5].get());
  bbDBStmt(2285570);
  f0.l_backButtonOPTION5->m_Name(bbString(L"back",4));
  bbDBStmt(2289666);
  f0.l_backButtonOPTION5->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(0)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btback.png",25),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2293762);
  f0.l_backButtonOPTION5->m_Surface.get()->m_DrawData(bbInt(t_pyro_gui_GuiState(3)),bbInt(0))->m_Image=g_pyro_framework_contentmanager_Content.get()->m_GetImage(bbString(L"asset::buttons/btbackon.png",27),((t_mojo_graphics_Shader*)0),t_mojo_graphics_TextureFlags(12));
  bbDBStmt(2297858);
  f0.l_backButtonOPTION5->m_Location=g_std_geom_Vec2_1i_to_Tt_std_geom_Vec2_1f_2_1f((f0.t1=t_std_geom_Vec2_1i{bbInt((bbFloat(g_default_WINDOW_0WIDTH)-f0.l_backButtonOPTION5->m_Width())),bbInt((bbFloat(g_default_WINDOW_0HEIGHT)-f0.l_backButtonOPTION5->m_Height()))}));
}
t_default_Menu::~t_default_Menu(){
}

void t_default_Menu::m_RunOnce(){
  bbDBFrame db_f{"RunOnce:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Menu*self=this;
  bbDBLocal("Self",&self);
}

void t_default_Menu::m_OnUpdate(){
  bbDBFrame db_f{"OnUpdate:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Menu*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3104770);
  g_default_Menu_guiLayer[g_default_Menu_guiPage].get()->m_Update();
}

void t_default_Menu::m_OnStop(){
  bbDBFrame db_f{"OnStop:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Menu*self=this;
  bbDBLocal("Self",&self);
}

void t_default_Menu::m_OnStart(){
  bbDBFrame db_f{"OnStart:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Menu*self=this;
  bbDBLocal("Self",&self);
}

void t_default_Menu::m_OnRender(t_mojo_graphics_Canvas* l_canvas){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Font* t0{};
    void gcMark(){
      bbGCMark(t0);
    }
  }f0{};
  bbDBFrame db_f{"OnRender:Void(canvas:mojo.graphics.Canvas)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Menu*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
  bbDBStmt(3022850);
  this->m_mouse=g_mojo_input_Mouse.get()->m_Location();
  bbDBStmt(3031048);
  bbFloat l_h=(f0.t0=l_canvas->m_Font())->m_Height();
  bbDBLocal("h",&l_h);
  bbDBStmt(3035138);
  l_canvas->m_DrawRect(0.0f,0.0f,50.0f,50.0f);
  bbDBStmt(3039234);
  l_canvas->m_DrawRect(0.0f,bbFloat(g_default_WINDOW_0HEIGHT),50.0f,50.0f);
  bbDBStmt(3043330);
  l_canvas->m_DrawRect(bbFloat(g_default_WINDOW_0WIDTH),0.0f,50.0f,50.0f);
  bbDBStmt(3047426);
  l_canvas->m_DrawRect(bbFloat(g_default_WINDOW_0WIDTH),bbFloat(g_default_WINDOW_0HEIGHT),50.0f,50.0f);
  bbDBStmt(3051522);
  this->m_lbsize.get()->m_Label.get()->m_Text=(bbString(L"Screen Size=",12)+g_default_virtualResolution.m_to_s());
  bbDBStmt(3055618);
  this->m_lblayout.get()->m_Label.get()->m_Text=((bbString(L"Layout=",7)+g_default_layout)+bbString(L" ('L' to cycle)",15));
  bbDBStmt(3059714);
  this->m_lbgravity.get()->m_Label.get()->m_Text=((bbString(L"Gravity=",8)+g_default_gravity.m_to_s())+bbString(L" ('G' to cycle)",15));
  bbDBStmt(3063810);
  this->m_lbmouse.get()->m_Label.get()->m_Text=(bbString(L"Mouse=",6)+this->m_mouse.m_to_s());
  bbDBStmt(3072002);
  l_canvas->m_Flush();
  bbDBStmt(3076098);
  g_default_Menu_guiLayer[g_default_Menu_guiPage].get()->m_Draw(l_canvas);
}

void t_default_Menu::m_OnMouseEvent(t_mojo_app_MouseEvent* l_event){
  bbDBFrame db_f{"OnMouseEvent:Void(event:mojo.app.MouseEvent)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Menu*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbDBStmt(3006466);
  g_default_Menu_guiLayer[g_default_Menu_guiPage].get()->m_SendMouseEvent(l_event);
}

void t_default_Menu::m_OnKeyEvent(t_mojo_app_KeyEvent* l_event){
  bbDBFrame db_f{"OnKeyEvent:Void(event:mojo.app.KeyEvent)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Menu*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbDBStmt(2949122);
  g_default_Menu_guiLayer[g_default_Menu_guiPage].get()->m_SendKeyEvent(l_event);
  t_mojo_app_EventType l_0=l_event->m_Type();
  bbDBLocal("0",&l_0);
  bbDBStmt(2957314);
  if((l_0==t_mojo_app_EventType(0))){
    bbDBBlock db_blk;
    t_mojo_input_Key l_1=l_event->m_Key();
    bbDBLocal("1",&l_1);
    bbDBStmt(2965507);
    if((l_1==t_mojo_input_Key(27))){
      bbDBBlock db_blk;
      bbDBStmt(2973701);
      g_default_Menu_guiPage=g_default_Menu_START;
    }
  }
}
bbString bbDBType(t_default_Menu**){
  return "default.Menu";
}
bbString bbDBValue(t_default_Menu**p){
  return bbDBObjectValue(*p);
}

void t_default_Button::dbEmit(){
  t_pyro_gui_GuiButton::dbEmit();
  puts( "[default.Button]");
}
t_default_Button::~t_default_Button(){
}

void t_default_Button::m_OnReleased(){
  bbDBFrame db_f{"OnReleased:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Button*self=this;
  bbDBLocal("Self",&self);
  bbString l_0=this->m_Name();
  bbDBLocal("0",&l_0);
  bbDBStmt(167938);
  if((l_0==bbString(L"option1",7))){
    bbDBBlock db_blk;
    bbDBStmt(176132);
    g_default_Menu_guiPage=g_default_Menu_OPTION1;
  }else if((l_0==bbString(L"option2",7))){
    bbDBBlock db_blk;
    bbDBStmt(184324);
    g_default_Menu_guiPage=g_default_Menu_OPTION2;
  }else if((l_0==bbString(L"option3",7))){
    bbDBBlock db_blk;
    bbDBStmt(192516);
    g_default_Menu_guiPage=g_default_Menu_OPTION3;
  }else if((l_0==bbString(L"option4",7))){
    bbDBBlock db_blk;
    bbDBStmt(200708);
    g_default_Menu_guiPage=g_default_Menu_OPTION4;
  }else if((l_0==bbString(L"option5",7))){
    bbDBBlock db_blk;
    bbDBStmt(208900);
    g_default_Menu_guiPage=g_default_Menu_OPTION5;
  }else if((l_0==bbString(L"settings",8))){
    bbDBBlock db_blk;
    bbDBStmt(217092);
    g_default_Menu_guiPage=g_default_Menu_SETTINGS;
  }else if((l_0==bbString(L"about",5))){
    bbDBBlock db_blk;
    bbDBStmt(225284);
    g_default_Menu_guiPage=g_default_Menu_ABOUT;
  }else if((l_0==bbString(L"help",4))){
    bbDBBlock db_blk;
    bbDBStmt(233476);
    g_default_Menu_guiPage=g_default_Menu_HELP;
  }else if((l_0==bbString(L"back",4))){
    bbDBBlock db_blk;
    bbDBStmt(241668);
    g_default_Menu_guiPage=g_default_Menu_START;
  }
}
bbString bbDBType(t_default_Button**){
  return "default.Button";
}
bbString bbDBValue(t_default_Button**p){
  return bbDBObjectValue(*p);
}

void t_default_Checkbox::dbEmit(){
  t_pyro_gui_GuiCheckbox::dbEmit();
  puts( "[default.Checkbox]");
}
t_default_Checkbox::~t_default_Checkbox(){
}

void t_default_Checkbox::m_OnReleased(){
  bbDBFrame db_f{"OnReleased:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_Checkbox*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(282626);
  if((this->m_Frame==bbInt(0))){
    bbDBBlock db_blk;
    bb_print((this->m_Name()+bbString(L" = On ( Frame 0 )",17)));
  }
  bbDBStmt(286722);
  if((this->m_Frame==1)){
    bbDBBlock db_blk;
    bb_print((this->m_Name()+bbString(L" = Off ( Frame 1 )",18)));
  }
}
bbString bbDBType(t_default_Checkbox**){
  return "default.Checkbox";
}
bbString bbDBValue(t_default_Checkbox**p){
  return bbDBObjectValue(*p);
}

void t_default_Player::dbEmit(){
  t_pyro_scenegraph_LayerSprite::dbEmit();
  puts( "[default.Player]");
}
t_default_Player::~t_default_Player(){
}
bbString bbDBType(t_default_Player**){
  return "default.Player";
}
bbString bbDBValue(t_default_Player**p){
  return bbDBObjectValue(*p);
}

void t_default_MenuOptions::dbEmit(){
  t_pyro_framework_screenmanager_ScreenManager::dbEmit();
  puts( "[default.MenuOptions]");
}

t_default_MenuOptions::t_default_MenuOptions(bbString l_title,bbInt l_width,bbInt l_height,t_mojo_app_WindowFlags l_flags):t_pyro_framework_screenmanager_ScreenManager(l_title,l_width,l_height,l_flags){
  bbDBFrame db_f{"new:Void(title:monkey.types.String,width:monkey.types.Int,height:monkey.types.Int,flags:mojo.app.WindowFlags)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_MenuOptions*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("title",&l_title);
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(3207170);
  this->m_ClearColor(t_std_graphics_Color{0.0f,0.0f,0.20000000000000001f,1.0f});
  bbDBStmt(3215362);
  this->m_Layout(bbString(L"letterbox",9));
  bbDBStmt(3227650);
  g_default_loader=bbGCNew<t_default_Loader>();
  bbDBStmt(3231746);
  g_default_game=bbGCNew<t_default_Game>();
  bbDBStmt(3235842);
  g_default_menu=bbGCNew<t_default_Menu>();
  bbDBStmt(3244034);
  g_default_loader.get()->m_FollowUpScreen(((t_pyro_framework_screenmanager_Screen*)(g_default_menu.get())));
}
t_default_MenuOptions::~t_default_MenuOptions(){
}

t_std_geom_Vec2_1i t_default_MenuOptions::m_OnMeasure(){
  bbDBFrame db_f{"OnMeasure:Vec2i:std.geom.Vec2<monkey.types.Int>()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_MenuOptions*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3518466);
  return g_default_virtualResolution;
}

void t_default_MenuOptions::m_OnKeyEvent(t_mojo_app_KeyEvent* l_event){
  bbDBFrame db_f{"OnKeyEvent:Void(event:mojo.app.KeyEvent)","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_MenuOptions*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  t_mojo_app_EventType l_0=l_event->m_Type();
  bbDBLocal("0",&l_0);
  bbDBStmt(3457026);
  if((l_0==t_mojo_app_EventType(0))){
    bbDBBlock db_blk;
    t_mojo_input_Key l_1=l_event->m_Key();
    bbDBLocal("1",&l_1);
    bbDBStmt(3465219);
    if((l_1==t_mojo_input_Key(108))){
      bbDBBlock db_blk;
      bbDBStmt(3473413);
      this->m_CycleLayout();
    }else if((l_1==t_mojo_input_Key(103))){
      bbDBBlock db_blk;
      bbDBStmt(3481605);
      this->m_CycleGravity();
    }else if((l_1==t_mojo_input_Key(114))){
      bbDBBlock db_blk;
      bbDBStmt(3489797);
      this->m_CycleVirtualRes();
    }
  }
}

void t_default_MenuOptions::m_CycleVirtualRes(){
  bbDBAssertSelf(this);
  bbDBFrame db_f{"CycleVirtualRes:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_MenuOptions*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3387394);
  if((g_default_virtualResolution.m_x==1920)){
    bbDBBlock db_blk;
    bbDBStmt(3395588);
    g_default_virtualResolution=t_std_geom_Vec2_1i{640,480};
  }else if((g_default_virtualResolution.m_x==640)){
    bbDBBlock db_blk;
    bbDBStmt(3403780);
    g_default_virtualResolution=t_std_geom_Vec2_1i{1024,768};
  }else if((g_default_virtualResolution.m_x==1024)){
    bbDBBlock db_blk;
    bbDBStmt(3411972);
    g_default_virtualResolution=t_std_geom_Vec2_1i{1280,720};
  }else if((g_default_virtualResolution.m_x==1280)){
    bbDBBlock db_blk;
    bbDBStmt(3420164);
    g_default_virtualResolution=t_std_geom_Vec2_1i{1920,1080};
  }
}

void t_default_MenuOptions::m_CycleLayout(){
  bbDBAssertSelf(this);
  bbDBFrame db_f{"CycleLayout:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_MenuOptions*self=this;
  bbDBLocal("Self",&self);
  bbString l_0=this->m_Layout();
  bbDBLocal("0",&l_0);
  bbDBStmt(3272706);
  if((l_0==bbString(L"fill",4))){
    bbDBBlock db_blk;
    bbDBStmt(3280900);
    this->m_Layout(bbString(L"letterbox",9));
  }else if((l_0==bbString(L"letterbox",9))){
    bbDBBlock db_blk;
    bbDBStmt(3289092);
    this->m_Layout(bbString(L"stretch",7));
  }else if((l_0==bbString(L"stretch",7))){
    bbDBBlock db_blk;
    bbDBStmt(3297284);
    this->m_Layout(bbString(L"float",5));
  }else if((l_0==bbString(L"float",5))){
    bbDBBlock db_blk;
    bbDBStmt(3305476);
    this->m_Layout(bbString(L"fill",4));
  }
  bbDBStmt(3313666);
  g_default_layout=this->m_Layout();
}

void t_default_MenuOptions::m_CycleGravity(){
  bbDBAssertSelf(this);
  bbDBFrame db_f{"CycleGravity:Void()","C:/Users/Arolodo Carvalho/Documents/_Monkey2/MenuTemplate/menutemplate.monkey2"};
  t_default_MenuOptions*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3342338);
  g_default_gravity.m_x+=0.5f;
  bbDBStmt(3346434);
  if((g_default_gravity.m_x>1.0f)){
    bbDBBlock db_blk;
    bbDBStmt(3350531);
    g_default_gravity.m_x=0.0f;
    bbDBStmt(3354627);
    g_default_gravity.m_y+=0.5f;
    bbDBStmt(3358723);
    if((g_default_gravity.m_y>1.0f)){
      bbDBBlock db_blk;
      g_default_gravity.m_y=0.0f;
    }
  }
  bbDBStmt(3366914);
  this->m_Gravity(g_default_gravity);
}
bbString bbDBType(t_default_MenuOptions**){
  return "default.MenuOptions";
}
bbString bbDBValue(t_default_MenuOptions**p){
  return bbDBObjectValue(*p);
}

void mx2_menutemplate_menutemplate_init_f(){
  g_default_FACEBOOK=bbString(L"https://www.facebook.com/pages/Playniax/289410737764922",55);
  g_default_TWITTER=bbString(L"https://twitter.com/playniax",28);
  g_default_PLAYNIAX=bbString(L"http://www.playniax.com",23);
  g_default_WINDOW_0WIDTH=1024;
  g_default_WINDOW_0HEIGHT=768;
  g_default_virtualResolution=t_std_geom_Vec2_1i{1280,720};
  g_default_Game_PAUSE=bbInt(0);
  g_default_Game_PAUSED=1;
  g_default_Game_guiLayer=bbArray<bbGCVar<t_pyro_gui_GuiLayer>>(2);
  g_default_Game_guiPage=g_default_Game_PAUSE;
  g_default_Menu_ABOUT=7;
  g_default_Menu_HELP=8;
  g_default_Menu_OPTION1=1;
  g_default_Menu_OPTION2=2;
  g_default_Menu_OPTION3=3;
  g_default_Menu_OPTION4=4;
  g_default_Menu_OPTION5=5;
  g_default_Menu_SETTINGS=6;
  g_default_Menu_START=bbInt(0);
  g_default_Menu_guiLayer=bbArray<bbGCVar<t_pyro_gui_GuiLayer>>(9);
  g_default_Menu_guiPage=g_default_Menu_START;
}

struct mx2_menutemplate_menutemplate_roots_t : bbGCRoot{
  void gcMark(){
    bbGCMark(g_default_game.get());
    bbGCMark(g_default_loader.get());
    bbGCMark(g_default_menu.get());
    bbGCMark(g_default_Game_camera.get());
    bbGCMark(g_default_Game_guiLayer);
    bbGCMark(g_default_Game_layer.get());
    bbGCMark(g_default_Game_scene.get());
    bbGCMark(g_default_Menu_guiLayer);
  }
}mx2_menutemplate_menutemplate_roots;
