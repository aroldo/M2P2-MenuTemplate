
#ifndef MX2_MENUTEMPLATE_MENUTEMPLATE_H
#define MX2_MENUTEMPLATE_MENUTEMPLATE_H

#include <bbmonkey.h>

struct t_default_Game;
struct t_default_Loader;
struct t_default_Menu;
struct t_default_Button;
struct t_default_Checkbox;
struct t_default_Player;
struct t_default_MenuOptions;

struct t_default_Game;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_default_Game* const& );
#endif
bbString bbDBType(t_default_Game**);
bbString bbDBValue(t_default_Game**);
struct t_default_Loader;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_default_Loader* const& );
#endif
bbString bbDBType(t_default_Loader**);
bbString bbDBValue(t_default_Loader**);
struct t_default_Menu;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_default_Menu* const& );
#endif
bbString bbDBType(t_default_Menu**);
bbString bbDBValue(t_default_Menu**);
struct t_pyro_gui_GuiLayer;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_pyro_gui_GuiLayer* const& );
#endif
bbString bbDBType(t_pyro_gui_GuiLayer**);
bbString bbDBValue(t_pyro_gui_GuiLayer**);
struct t_pyro_scenegraph_Camera;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_pyro_scenegraph_Camera* const& );
#endif
bbString bbDBType(t_pyro_scenegraph_Camera**);
bbString bbDBValue(t_pyro_scenegraph_Camera**);
struct t_pyro_scenegraph_Layer;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_pyro_scenegraph_Layer* const& );
#endif
bbString bbDBType(t_pyro_scenegraph_Layer**);
bbString bbDBValue(t_pyro_scenegraph_Layer**);
struct t_pyro_scenegraph_Scene;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_pyro_scenegraph_Scene* const& );
#endif
bbString bbDBType(t_pyro_scenegraph_Scene**);
bbString bbDBValue(t_pyro_scenegraph_Scene**);
struct t_std_geom_Vec2_1f;
bbString bbDBType(t_std_geom_Vec2_1f*);
bbString bbDBValue(t_std_geom_Vec2_1f*);
struct t_std_geom_Vec2_1i;
bbString bbDBType(t_std_geom_Vec2_1i*);
bbString bbDBValue(t_std_geom_Vec2_1i*);


extern bbString g_default_FACEBOOK;
extern bbString g_default_TWITTER;
extern bbString g_default_PLAYNIAX;
extern bbInt g_default_WINDOW_0WIDTH;
extern bbInt g_default_WINDOW_0HEIGHT;
extern bbGCVar<t_default_Game> g_default_game;
extern bbGCVar<t_default_Loader> g_default_loader;
extern bbGCVar<t_default_Menu> g_default_menu;
extern t_std_geom_Vec2_1i g_default_virtualResolution;
extern bbString g_default_layout;
extern t_std_geom_Vec2_1f g_default_gravity;
extern bbInt g_default_Game_PAUSE;
extern bbInt g_default_Game_PAUSED;
extern bbGCVar<t_pyro_scenegraph_Camera> g_default_Game_camera;
extern bbArray<bbGCVar<t_pyro_gui_GuiLayer>> g_default_Game_guiLayer;
extern bbInt g_default_Game_guiPage;
extern bbGCVar<t_pyro_scenegraph_Layer> g_default_Game_layer;
extern bbGCVar<t_pyro_scenegraph_Scene> g_default_Game_scene;
extern bbInt g_default_Menu_ABOUT;
extern bbInt g_default_Menu_HELP;
extern bbInt g_default_Menu_OPTION1;
extern bbInt g_default_Menu_OPTION2;
extern bbInt g_default_Menu_OPTION3;
extern bbInt g_default_Menu_OPTION4;
extern bbInt g_default_Menu_OPTION5;
extern bbInt g_default_Menu_SETTINGS;
extern bbInt g_default_Menu_START;
extern bbArray<bbGCVar<t_pyro_gui_GuiLayer>> g_default_Menu_guiLayer;
extern bbInt g_default_Menu_guiPage;

extern void bbMain();

// Class default.Game

#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_screenmanager.h"

struct t_mojo_app_KeyEvent;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_app_KeyEvent* const& );
#endif
bbString bbDBType(t_mojo_app_KeyEvent**);
bbString bbDBValue(t_mojo_app_KeyEvent**);
struct t_mojo_app_MouseEvent;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_app_MouseEvent* const& );
#endif
bbString bbDBType(t_mojo_app_MouseEvent**);
bbString bbDBValue(t_mojo_app_MouseEvent**);
struct t_mojo_graphics_Canvas;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_graphics_Canvas* const& );
#endif
bbString bbDBType(t_mojo_graphics_Canvas**);
bbString bbDBValue(t_mojo_graphics_Canvas**);


struct t_default_Game : public t_pyro_framework_screenmanager_Screen{
  typedef t_default_Game *bb_object_type;

  bbTypeInfo *typeof()const;
  const char *typeName()const{return "t_default_Game";}

  void dbEmit();

  t_default_Game();
  ~t_default_Game();

  void m_RunOnce();
  void m_OnUpdate();
  void m_OnStop();
  void m_OnStart();
  void m_OnRender(t_mojo_graphics_Canvas* l_canvas);
  void m_OnMouseEvent(t_mojo_app_MouseEvent* l_event);
  void m_OnKeyEvent(t_mojo_app_KeyEvent* l_event);
};
bbTypeInfo *bbGetType( t_default_Game* const& );
bbString bbDBType(t_default_Game**);
bbString bbDBValue(t_default_Game**);

// Class default.Loader

#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_loaderscreen.h"

struct t_mojo_graphics_Canvas;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_graphics_Canvas* const& );
#endif
bbString bbDBType(t_mojo_graphics_Canvas**);
bbString bbDBValue(t_mojo_graphics_Canvas**);
struct t_pyro_gui_GuiHProgressBar;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_pyro_gui_GuiHProgressBar* const& );
#endif
bbString bbDBType(t_pyro_gui_GuiHProgressBar**);
bbString bbDBValue(t_pyro_gui_GuiHProgressBar**);
struct t_pyro_gui_GuiLayer;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_pyro_gui_GuiLayer* const& );
#endif
bbString bbDBType(t_pyro_gui_GuiLayer**);
bbString bbDBValue(t_pyro_gui_GuiLayer**);


struct t_default_Loader : public t_pyro_framework_loaderscreen_LoaderScreen{
  typedef t_default_Loader *bb_object_type;

  bbTypeInfo *typeof()const;
  const char *typeName()const{return "t_default_Loader";}

  bbGCVar<t_pyro_gui_GuiLayer> m_guiLayer{};
  bbGCVar<t_pyro_gui_GuiHProgressBar> m_progressBar{};

  void gcMark();
  void dbEmit();

  t_default_Loader();
  ~t_default_Loader();

  void m_RunOnce();
  void m_OnUpdate();
  void m_OnStop();
  void m_OnStart();
  void m_OnRender(t_mojo_graphics_Canvas* l_canvas);
  void m_OnLoading();
};
bbTypeInfo *bbGetType( t_default_Loader* const& );
bbString bbDBType(t_default_Loader**);
bbString bbDBValue(t_default_Loader**);

// Class default.Menu

#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_screenmanager.h"
#include "std/std.buildv1.1.09/windows_debug/include/std_geom_2vec2.h"

struct t_mojo_app_KeyEvent;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_app_KeyEvent* const& );
#endif
bbString bbDBType(t_mojo_app_KeyEvent**);
bbString bbDBValue(t_mojo_app_KeyEvent**);
struct t_mojo_app_MouseEvent;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_app_MouseEvent* const& );
#endif
bbString bbDBType(t_mojo_app_MouseEvent**);
bbString bbDBValue(t_mojo_app_MouseEvent**);
struct t_mojo_graphics_Canvas;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_graphics_Canvas* const& );
#endif
bbString bbDBType(t_mojo_graphics_Canvas**);
bbString bbDBValue(t_mojo_graphics_Canvas**);
struct t_pyro_gui_GuiLabel;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_pyro_gui_GuiLabel* const& );
#endif
bbString bbDBType(t_pyro_gui_GuiLabel**);
bbString bbDBValue(t_pyro_gui_GuiLabel**);


struct t_default_Menu : public t_pyro_framework_screenmanager_Screen{
  typedef t_default_Menu *bb_object_type;

  bbTypeInfo *typeof()const;
  const char *typeName()const{return "t_default_Menu";}

  t_std_geom_Vec2_1i m_mouse{};
  bbInt m_lbposy=80;
  bbInt m_lbposx=150;
  bbGCVar<t_pyro_gui_GuiLabel> m_lbsize{};
  bbGCVar<t_pyro_gui_GuiLabel> m_lblayout{};
  bbGCVar<t_pyro_gui_GuiLabel> m_lbgravity{};
  bbGCVar<t_pyro_gui_GuiLabel> m_lbmouse{};

  void gcMark();
  void dbEmit();

  t_default_Menu();
  ~t_default_Menu();

  void m_RunOnce();
  void m_OnUpdate();
  void m_OnStop();
  void m_OnStart();
  void m_OnRender(t_mojo_graphics_Canvas* l_canvas);
  void m_OnMouseEvent(t_mojo_app_MouseEvent* l_event);
  void m_OnKeyEvent(t_mojo_app_KeyEvent* l_event);
};
bbTypeInfo *bbGetType( t_default_Menu* const& );
bbString bbDBType(t_default_Menu**);
bbString bbDBValue(t_default_Menu**);

// Class default.Button

#include "pyro-gui/pyro-gui.buildv1.1.09/windows_debug/include/pyro_5gui_pyro_5gui.h"


struct t_default_Button : public t_pyro_gui_GuiButton{
  typedef t_default_Button *bb_object_type;

  bbTypeInfo *typeof()const;
  const char *typeName()const{return "t_default_Button";}

  void dbEmit();

  ~t_default_Button();

  void m_OnReleased();

  t_default_Button(){
  }
};
bbTypeInfo *bbGetType( t_default_Button* const& );
bbString bbDBType(t_default_Button**);
bbString bbDBValue(t_default_Button**);

// Class default.Checkbox

#include "pyro-gui/pyro-gui.buildv1.1.09/windows_debug/include/pyro_5gui_pyro_5gui.h"


struct t_default_Checkbox : public t_pyro_gui_GuiCheckbox{
  typedef t_default_Checkbox *bb_object_type;

  bbTypeInfo *typeof()const;
  const char *typeName()const{return "t_default_Checkbox";}

  void dbEmit();

  ~t_default_Checkbox();

  void m_OnReleased();

  t_default_Checkbox(){
  }
};
bbTypeInfo *bbGetType( t_default_Checkbox* const& );
bbString bbDBType(t_default_Checkbox**);
bbString bbDBValue(t_default_Checkbox**);

// Class default.Player

#include "pyro-scenegraph/pyro-scenegraph.buildv1.1.09/windows_debug/include/pyro_5scenegraph_pyro_5scenegraph.h"


struct t_default_Player : public t_pyro_scenegraph_LayerSprite{
  typedef t_default_Player *bb_object_type;

  bbTypeInfo *typeof()const;
  const char *typeName()const{return "t_default_Player";}

  void dbEmit();

  ~t_default_Player();

  t_default_Player(){
  }
};
bbTypeInfo *bbGetType( t_default_Player* const& );
bbString bbDBType(t_default_Player**);
bbString bbDBValue(t_default_Player**);

// Class default.MenuOptions

#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_screenmanager.h"

struct t_mojo_app_KeyEvent;
#ifdef BB_NEWREFLECTION
bbTypeInfo *bbGetType( t_mojo_app_KeyEvent* const& );
#endif
bbString bbDBType(t_mojo_app_KeyEvent**);
bbString bbDBValue(t_mojo_app_KeyEvent**);
enum class t_mojo_app_WindowFlags;
bbString bbDBType(t_mojo_app_WindowFlags*);
bbString bbDBValue(t_mojo_app_WindowFlags*);
struct t_std_geom_Vec2_1i;
bbString bbDBType(t_std_geom_Vec2_1i*);
bbString bbDBValue(t_std_geom_Vec2_1i*);


struct t_default_MenuOptions : public t_pyro_framework_screenmanager_ScreenManager{
  typedef t_default_MenuOptions *bb_object_type;

  bbTypeInfo *typeof()const;
  const char *typeName()const{return "t_default_MenuOptions";}

  void dbEmit();

  t_default_MenuOptions(bbString l_title,bbInt l_width,bbInt l_height,t_mojo_app_WindowFlags l_flags);
  ~t_default_MenuOptions();

  t_std_geom_Vec2_1i m_OnMeasure();
  void m_OnKeyEvent(t_mojo_app_KeyEvent* l_event);
  void m_CycleVirtualRes();
  void m_CycleLayout();
  void m_CycleGravity();

  t_default_MenuOptions(){
  }
};
bbTypeInfo *bbGetType( t_default_MenuOptions* const& );
bbString bbDBType(t_default_MenuOptions**);
bbString bbDBValue(t_default_MenuOptions**);

#endif
