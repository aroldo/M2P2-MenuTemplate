#include <bbmonkey.h>
#if BB_NEWREFLECTION
#include "_r.h"
#endif

#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_app_2event.h"
#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_app_2window.h"
#include "mojo/mojo.buildv1.1.09/windows_debug/include/mojo_graphics_2canvas.h"
#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_loaderscreen.h"
#include "pyro-framework/pyro-framework.buildv1.1.09/windows_debug/include/pyro_5framework_screenmanager.h"
#include "pyro-gui/pyro-gui.buildv1.1.09/windows_debug/include/pyro_5gui_pyro_5gui.h"
#include "pyro-scenegraph/pyro-scenegraph.buildv1.1.09/windows_debug/include/pyro_5scenegraph_pyro_5scenegraph.h"
#include "std/std.buildv1.1.09/windows_debug/include/std_geom_2vec2.h"
#include "menutemplate.buildv1.1.09/windows_debug/include/menutemplate_menutemplate.h"

#if BB_R_default || BB_R_default__
static struct mx2_menutemplate_menutemplate_typeinfo : public bbClassDecls{
  mx2_menutemplate_menutemplate_typeinfo():bbClassDecls(bbClassTypeInfo::getNamespace("default")){
  }
  bbDeclInfo **initDecls(){
    return bbMembers(bbConstDecl("FACEBOOK",&g_default_FACEBOOK),bbConstDecl("TWITTER",&g_default_TWITTER),bbConstDecl("PLAYNIAX",&g_default_PLAYNIAX),bbConstDecl("WINDOW_WIDTH",&g_default_WINDOW_0WIDTH),bbConstDecl("WINDOW_HEIGHT",&g_default_WINDOW_0HEIGHT),bbGlobalDecl("game",&g_default_game),bbGlobalDecl("loader",&g_default_loader),bbGlobalDecl("menu",&g_default_menu),bbGlobalDecl("virtualResolution",&g_default_virtualResolution),bbGlobalDecl("layout",&g_default_layout),bbGlobalDecl("gravity",&g_default_gravity),bbFunctionDecl<void>("Main",&bbMain));
  }
}_mx2_menutemplate_menutemplate_typeinfo;

struct rt_default_Game : public bbClassTypeInfo{
  static rt_default_Game instance;
  static struct decls_t : public bbClassDecls{
    decls_t():bbClassDecls(&instance){}
    bbDeclInfo **initDecls(){
      return bbMembers(bbCtorDecl<t_default_Game>(),bbMethodDecl<t_default_Game,void>("RunOnce",&t_default_Game::m_RunOnce),bbMethodDecl<t_default_Game,void>("OnUpdate",&t_default_Game::m_OnUpdate),bbMethodDecl<t_default_Game,void>("OnStop",&t_default_Game::m_OnStop),bbMethodDecl<t_default_Game,void>("OnStart",&t_default_Game::m_OnStart),bbMethodDecl<t_default_Game,void,t_mojo_graphics_Canvas*>("OnRender",&t_default_Game::m_OnRender),bbMethodDecl<t_default_Game,void,t_mojo_app_MouseEvent*>("OnMouseEvent",&t_default_Game::m_OnMouseEvent),bbMethodDecl<t_default_Game,void,t_mojo_app_KeyEvent*>("OnKeyEvent",&t_default_Game::m_OnKeyEvent),bbConstDecl("PAUSE",&g_default_Game_PAUSE),bbConstDecl("PAUSED",&g_default_Game_PAUSED),bbGlobalDecl("camera",&g_default_Game_camera),bbGlobalDecl("guiLayer",&g_default_Game_guiLayer),bbGlobalDecl("guiPage",&g_default_Game_guiPage),bbGlobalDecl("layer",&g_default_Game_layer),bbGlobalDecl("scene",&g_default_Game_scene));
    }
  }decls;
  rt_default_Game():bbClassTypeInfo("default.Game","Class"){
  }
  bbTypeInfo *superType(){
    return bbGetType<t_pyro_framework_screenmanager_Screen*>();
  }
};
rt_default_Game rt_default_Game::instance;
rt_default_Game::decls_t rt_default_Game::decls;

bbTypeInfo *bbGetType( t_default_Game* const& ){
  return &rt_default_Game::instance;
}
bbTypeInfo *t_default_Game::typeof()const{
  return &rt_default_Game::instance;
}

struct rt_default_Loader : public bbClassTypeInfo{
  static rt_default_Loader instance;
  static struct decls_t : public bbClassDecls{
    decls_t():bbClassDecls(&instance){}
    bbDeclInfo **initDecls(){
      return bbMembers(bbCtorDecl<t_default_Loader>(),bbFieldDecl("guiLayer",&t_default_Loader::m_guiLayer),bbFieldDecl("progressBar",&t_default_Loader::m_progressBar),bbMethodDecl<t_default_Loader,void>("RunOnce",&t_default_Loader::m_RunOnce),bbMethodDecl<t_default_Loader,void>("OnUpdate",&t_default_Loader::m_OnUpdate),bbMethodDecl<t_default_Loader,void>("OnStop",&t_default_Loader::m_OnStop),bbMethodDecl<t_default_Loader,void>("OnStart",&t_default_Loader::m_OnStart),bbMethodDecl<t_default_Loader,void,t_mojo_graphics_Canvas*>("OnRender",&t_default_Loader::m_OnRender),bbMethodDecl<t_default_Loader,void>("OnLoading",&t_default_Loader::m_OnLoading));
    }
  }decls;
  rt_default_Loader():bbClassTypeInfo("default.Loader","Class"){
  }
  bbTypeInfo *superType(){
    return bbGetType<t_pyro_framework_loaderscreen_LoaderScreen*>();
  }
};
rt_default_Loader rt_default_Loader::instance;
rt_default_Loader::decls_t rt_default_Loader::decls;

bbTypeInfo *bbGetType( t_default_Loader* const& ){
  return &rt_default_Loader::instance;
}
bbTypeInfo *t_default_Loader::typeof()const{
  return &rt_default_Loader::instance;
}

struct rt_default_Menu : public bbClassTypeInfo{
  static rt_default_Menu instance;
  static struct decls_t : public bbClassDecls{
    decls_t():bbClassDecls(&instance){}
    bbDeclInfo **initDecls(){
      return bbMembers(bbCtorDecl<t_default_Menu>(),bbFieldDecl("mouse",&t_default_Menu::m_mouse),bbFieldDecl("lbposy",&t_default_Menu::m_lbposy),bbFieldDecl("lbposx",&t_default_Menu::m_lbposx),bbFieldDecl("lbsize",&t_default_Menu::m_lbsize),bbFieldDecl("lblayout",&t_default_Menu::m_lblayout),bbFieldDecl("lbgravity",&t_default_Menu::m_lbgravity),bbFieldDecl("lbmouse",&t_default_Menu::m_lbmouse),bbMethodDecl<t_default_Menu,void>("RunOnce",&t_default_Menu::m_RunOnce),bbMethodDecl<t_default_Menu,void>("OnUpdate",&t_default_Menu::m_OnUpdate),bbMethodDecl<t_default_Menu,void>("OnStop",&t_default_Menu::m_OnStop),bbMethodDecl<t_default_Menu,void>("OnStart",&t_default_Menu::m_OnStart),bbMethodDecl<t_default_Menu,void,t_mojo_graphics_Canvas*>("OnRender",&t_default_Menu::m_OnRender),bbMethodDecl<t_default_Menu,void,t_mojo_app_MouseEvent*>("OnMouseEvent",&t_default_Menu::m_OnMouseEvent),bbMethodDecl<t_default_Menu,void,t_mojo_app_KeyEvent*>("OnKeyEvent",&t_default_Menu::m_OnKeyEvent),bbConstDecl("ABOUT",&g_default_Menu_ABOUT),bbConstDecl("HELP",&g_default_Menu_HELP),bbConstDecl("OPTION1",&g_default_Menu_OPTION1),bbConstDecl("OPTION2",&g_default_Menu_OPTION2),bbConstDecl("OPTION3",&g_default_Menu_OPTION3),bbConstDecl("OPTION4",&g_default_Menu_OPTION4),bbConstDecl("OPTION5",&g_default_Menu_OPTION5),bbConstDecl("SETTINGS",&g_default_Menu_SETTINGS),bbConstDecl("START",&g_default_Menu_START),bbGlobalDecl("guiLayer",&g_default_Menu_guiLayer),bbGlobalDecl("guiPage",&g_default_Menu_guiPage));
    }
  }decls;
  rt_default_Menu():bbClassTypeInfo("default.Menu","Class"){
  }
  bbTypeInfo *superType(){
    return bbGetType<t_pyro_framework_screenmanager_Screen*>();
  }
};
rt_default_Menu rt_default_Menu::instance;
rt_default_Menu::decls_t rt_default_Menu::decls;

bbTypeInfo *bbGetType( t_default_Menu* const& ){
  return &rt_default_Menu::instance;
}
bbTypeInfo *t_default_Menu::typeof()const{
  return &rt_default_Menu::instance;
}

struct rt_default_Button : public bbClassTypeInfo{
  static rt_default_Button instance;
  static struct decls_t : public bbClassDecls{
    decls_t():bbClassDecls(&instance){}
    bbDeclInfo **initDecls(){
      return bbMembers(bbCtorDecl<t_default_Button>(),bbMethodDecl<t_default_Button,void>("OnReleased",&t_default_Button::m_OnReleased));
    }
  }decls;
  rt_default_Button():bbClassTypeInfo("default.Button","Class"){
  }
  bbTypeInfo *superType(){
    return bbGetType<t_pyro_gui_GuiButton*>();
  }
};
rt_default_Button rt_default_Button::instance;
rt_default_Button::decls_t rt_default_Button::decls;

bbTypeInfo *bbGetType( t_default_Button* const& ){
  return &rt_default_Button::instance;
}
bbTypeInfo *t_default_Button::typeof()const{
  return &rt_default_Button::instance;
}

struct rt_default_Checkbox : public bbClassTypeInfo{
  static rt_default_Checkbox instance;
  static struct decls_t : public bbClassDecls{
    decls_t():bbClassDecls(&instance){}
    bbDeclInfo **initDecls(){
      return bbMembers(bbCtorDecl<t_default_Checkbox>(),bbMethodDecl<t_default_Checkbox,void>("OnReleased",&t_default_Checkbox::m_OnReleased));
    }
  }decls;
  rt_default_Checkbox():bbClassTypeInfo("default.Checkbox","Class"){
  }
  bbTypeInfo *superType(){
    return bbGetType<t_pyro_gui_GuiCheckbox*>();
  }
};
rt_default_Checkbox rt_default_Checkbox::instance;
rt_default_Checkbox::decls_t rt_default_Checkbox::decls;

bbTypeInfo *bbGetType( t_default_Checkbox* const& ){
  return &rt_default_Checkbox::instance;
}
bbTypeInfo *t_default_Checkbox::typeof()const{
  return &rt_default_Checkbox::instance;
}

struct rt_default_Player : public bbClassTypeInfo{
  static rt_default_Player instance;
  static struct decls_t : public bbClassDecls{
    decls_t():bbClassDecls(&instance){}
    bbDeclInfo **initDecls(){
      return bbMembers(bbCtorDecl<t_default_Player>());
    }
  }decls;
  rt_default_Player():bbClassTypeInfo("default.Player","Class"){
  }
  bbTypeInfo *superType(){
    return bbGetType<t_pyro_scenegraph_LayerSprite*>();
  }
};
rt_default_Player rt_default_Player::instance;
rt_default_Player::decls_t rt_default_Player::decls;

bbTypeInfo *bbGetType( t_default_Player* const& ){
  return &rt_default_Player::instance;
}
bbTypeInfo *t_default_Player::typeof()const{
  return &rt_default_Player::instance;
}

struct rt_default_MenuOptions : public bbClassTypeInfo{
  static rt_default_MenuOptions instance;
  static struct decls_t : public bbClassDecls{
    decls_t():bbClassDecls(&instance){}
    bbDeclInfo **initDecls(){
      return bbMembers(bbCtorDecl<t_default_MenuOptions,bbString,bbInt,bbInt,t_mojo_app_WindowFlags>(),bbMethodDecl<t_default_MenuOptions,t_std_geom_Vec2_1i>("OnMeasure",&t_default_MenuOptions::m_OnMeasure),bbMethodDecl<t_default_MenuOptions,void,t_mojo_app_KeyEvent*>("OnKeyEvent",&t_default_MenuOptions::m_OnKeyEvent),bbMethodDecl<t_default_MenuOptions,void>("CycleVirtualRes",&t_default_MenuOptions::m_CycleVirtualRes),bbMethodDecl<t_default_MenuOptions,void>("CycleLayout",&t_default_MenuOptions::m_CycleLayout),bbMethodDecl<t_default_MenuOptions,void>("CycleGravity",&t_default_MenuOptions::m_CycleGravity));
    }
  }decls;
  rt_default_MenuOptions():bbClassTypeInfo("default.MenuOptions","Class"){
  }
  bbTypeInfo *superType(){
    return bbGetType<t_pyro_framework_screenmanager_ScreenManager*>();
  }
};
rt_default_MenuOptions rt_default_MenuOptions::instance;
rt_default_MenuOptions::decls_t rt_default_MenuOptions::decls;

bbTypeInfo *bbGetType( t_default_MenuOptions* const& ){
  return &rt_default_MenuOptions::instance;
}
bbTypeInfo *t_default_MenuOptions::typeof()const{
  return &rt_default_MenuOptions::instance;
}
#else
bbTypeInfo *bbGetType(t_default_Game* const&){
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *t_default_Game::typeof()const{
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *bbGetType(t_default_Loader* const&){
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *t_default_Loader::typeof()const{
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *bbGetType(t_default_Menu* const&){
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *t_default_Menu::typeof()const{
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *bbGetType(t_default_Button* const&){
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *t_default_Button::typeof()const{
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *bbGetType(t_default_Checkbox* const&){
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *t_default_Checkbox::typeof()const{
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *bbGetType(t_default_Player* const&){
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *t_default_Player::typeof()const{
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *bbGetType(t_default_MenuOptions* const&){
  return &bbObjectTypeInfo::instance;
}
bbTypeInfo *t_default_MenuOptions::typeof()const{
  return &bbObjectTypeInfo::instance;
}
#endif